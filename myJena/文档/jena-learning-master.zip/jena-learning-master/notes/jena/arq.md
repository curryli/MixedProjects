# ARQ

## 1. 简介

 ARQ是Jena中的一个SPARQL查询的处理器，支持：
 
 1. 标准的SPARQL查询
 2. 文本搜索（Lucene）
 3. SPARQL中的更新操作
 4. 支持SPARQL代数？
 5. 支持自定义filter函数
 ...

 SPARQL algebra
 
 
## 2. SPARQL查询API

[完整示例](../../arq/QueryExample.java)



